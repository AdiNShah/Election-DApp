# Election-Portal
Ethereum Dapp - Election portal in Solidity (blockchain programming)

The initial code has been adopted from a video tutorial by Dapp University. 

New features added:
1. Added a timer to election. Before the timer only candidates are displayed. After the timer only results are displayed.
2. Changed the UI by creating 3 versions. No voter can see the current number of votes of a candidate during the election.
